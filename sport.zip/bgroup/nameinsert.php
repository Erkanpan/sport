<?php

$datem = $_POST['datem'];

$name = $_POST['name'];

include "ayark.php";
  
$veri = $db->prepare("SELECT * FROM bgroup WHERE dat=:dat and nam=:nam ");

$veri->execute([':dat'=>  $datem,':nam'=>  $name]);
  
$gen = $veri -> rowcount();

if ($gen == 0) {

try {
include "ayark.php";
	 
$db-> setAttribute (PDO :: ATTR_ERRMODE, PDO :: ERRMODE_WARNING);


$ekle = $db->exec("INSERT INTO bgroup (dat, nam )  VALUES ('$datem', '$name' )");

header("location : bgroup.php?can=uyarim");
} catch ( PDOException $e ){
     echo "Bir Hata Oluştu: ".$e->getMessage();
 }
} else {

header("location : bgroup.php?not=uyari");
}


?>