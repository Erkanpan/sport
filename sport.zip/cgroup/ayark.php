<?php

$db = new PDO("mysql:host=localhost;dbname=u0718940_datam;charset=utf8","u0718940_erhan","Ksl6lcohyRLJg");


?>