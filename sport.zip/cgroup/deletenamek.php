<?php

$datem = $_POST['datem'];

$name = $_POST['name'];

include "ayark.php";
  
$veri = $db->prepare("SELECT * FROM cgroup WHERE  nam=:nam ");

$veri->execute([':nam'=>  $name]);
  
$gen = $veri -> rowcount();

if ($gen > 0) {

try {

   
$db-> setAttribute (PDO :: ATTR_ERRMODE, PDO :: ERRMODE_WARNING);




$cek = $db->prepare("DELETE FROM cgroup WHERE nam = '$name' ");
$cek->execute();

header("location : deletename.php?can=uyarim");
} catch ( PDOException $e ){
     echo "Bir Hata Oluştu: ".$e->getMessage();
 }
} else {

header("location : deletename.php?not=uyari");
}


?>