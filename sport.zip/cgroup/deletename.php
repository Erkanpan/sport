<html>
<head>
	<title></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body {  background-image: url("deniz.jpg");

  
  height: 100%;

 
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
} 
</style>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<br><br>
<br>
<center>
Delete Name
<br><br>
<?php
$nota = $_GET['not'];
if(isset($nota)){
echo "Could not delete because you are not in the list."; 
}
?>

<?php
$notk = $_GET['can'];
if(isset($notk)){
echo "you have been deleted."; 
}
?>
<table>
<tr> <td>
<form method="post" action="deletenamek.php">
  <input type="hidden" name="datem" value="<?php echo date('Y/m/d')  ?>"> <br>
  <div class="form-group">
    <label>Name Surname</label>
    <input type="text" required name="name" maxlength="50" class="form-control" >
  </div>

  
  <br>
  <input type="submit" value="Delete" class="btn btn-warning">
  <br><br><br>
  
</form>
</td></tr>
</table>
<br><br><br><br><br>

</center>
</body>
</html>