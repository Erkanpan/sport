

<html>
<head>
	<title></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body {  background-image: url("deniz.jpg");

  
  height: 100%;

 
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
} 
</style>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<br><br>

<br>
<center>
Add Name
<br><br>
<?php
$nota = $_GET['not'];
if(isset($nota)){
echo "Your name is available."; 
}
?>

<?php
$notk = $_GET['can'];
if(isset($notk)){
echo "You have been added to the queue.."; 
}
?>
<table>
<tr> <td>
<form method="post" action="nameinsert.php">
  <input type="hidden" name="datem" value="<?php echo date("Y/m/d")  ?>"> <br>
  <div class="form-group">
    <label>Name Surname</label>
    <input type="text" required name="name" maxlength="50" class="form-control" >
  </div>

  
  <br>
  <input type="submit" value="İnsert" class="btn btn-warning">
  <br><br><br>
  <a href="deletename.php"><p style="color: white"><button type="button" class="btn btn-secondary">Delete your name from the list.</button></p></a>
</form>
<br>
  <a href="/index.php"><p style="color: white"><button type="button" class="btn btn-primary">Home Page</button></p></a>
</td></tr>
</table>
<br><br><br><br><br>

</center>
</body>
</html>