<?php

$db = new PDO("mysql:host=sql112.epizy.com;dbname=epiz_31905944_komple;charset=utf8","epiz_31905944","Ksl6lcohyRLJg");


?>