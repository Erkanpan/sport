<?php

$datem = $_POST['datem'];

$name = $_POST['name'];

include "ayark.php";
  
$veri = $db->prepare("SELECT * FROM agroup WHERE dat=:dat and nam=:nam ");

$veri->execute([':dat'=>  $datem,':nam'=>  $name]);
  
$gen = $veri -> rowcount();

if ($gen == 0) {

try {

	 
$db-> setAttribute (PDO :: ATTR_ERRMODE, PDO :: ERRMODE_WARNING);


$ekle = $db->exec("INSERT INTO agroup (dat, nam )  VALUES ('$datem', '$name' )");

header("location : agroup.php?can=uyarim");
} catch ( PDOException $e ){
     echo "Bir Hata Oluştu: ".$e->getMessage();
 }
} else {

header("location : agroup.php?not=uyari");
}


?>